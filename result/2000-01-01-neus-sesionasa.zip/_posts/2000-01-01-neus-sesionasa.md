---
# Archivo autogenerado

# No tocar
layout: gallery

# Título en la página /sesiones
title: "Neus"

# Carpeta donde buscará las imágenes en /images/. Debe tener el mismo nombre y sin espacios
images: carpeta-toguapa

# Enlace personalizado ej: ariadnaballestar.com/sesiones/NOMBRESESION
permalink: /neus-sesionasa

# Información detallada sobre la sesión
description: "Pues fue muy diver"

# Colaboradores
colaboradores:
 - title: "asda"
   name: "asda"
---