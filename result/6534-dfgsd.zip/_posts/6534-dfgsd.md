---
# Archivo autogenerado

# No tocar
layout: gallery

# Título en la página /sesiones
title: "dgds"

# Carpeta donde buscará las imágenes en /images/. Debe tener el mismo nombre y sin espacios
images: sdfgfsd

# Enlace personalizado ej: ariadnaballestar.com/sesiones/NOMBRESESION
permalink: /dfgsd

# Información detallada sobre la sesión
description: "sdfgds"

# Colaboradores
colaboradores:
 - title: "saf"
   name: "asfd"
---