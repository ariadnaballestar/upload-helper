---
# Archivo autogenerado

# No tocar
layout: gallery

# Título en la página /sesiones
title: "fdghfd"

# Carpeta donde buscará las imágenes en /images/. Debe tener el mismo nombre y sin espacios
images: fghd

# Enlace personalizado ej: ariadnaballestar.com/sesiones/NOMBRESESION
permalink: /dfghd

# Información detallada sobre la sesión
description: "dhf"

# Colaboradores
colaboradores:
 - title: "2314"
   name: "324"
---